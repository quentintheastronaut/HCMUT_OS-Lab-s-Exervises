#ifndef EX_1
#define EX_1

void *aligned_malloc(unsigned int size, unsigned int align);
void *aligned_free(void *ptr);


#endif

